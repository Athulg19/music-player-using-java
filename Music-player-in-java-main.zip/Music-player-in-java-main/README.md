# Music-player-in-java

This is a music player made in Java using the Java data structures and Algorithm

Data structures used are:- 

                           Stack

                           Queue
                           
use Driver.java file to run this application and through that interface you can create, delete palylist, add songs to it. Play songs in a queue etc.

only .wav audio files will work and to access it put the songs in music folder.

in case of any doubt contact:-

  adithyalennzer@gmail.com

  athulg2002@gmail.com

  adithyasnair2021@gmail.com
